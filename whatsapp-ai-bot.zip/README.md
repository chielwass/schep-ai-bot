# WhatsApp AI Bot voor Vastgoedbedrijven

Een eenvoudige Flask-applicatie die WhatsApp-berichten verwerkt en via OpenAI GPT-3.5-Turbo intelligente antwoorden geeft. Ideaal voor klantenservice, huurdersvragen of leadopvolging in vastgoed.

## Benodigdheden
- OpenAI API key
- Twilio WhatsApp Sandbox
- Python + Flask

## Starten
1. Voeg je OpenAI key toe aan een `.env` bestand
2. Installeer dependencies met `pip install -r requirements.txt`
3. Start de app: `python app.py`
